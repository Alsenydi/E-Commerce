
public enum USER_TYPE { // This enum is used to maintain user type
	CUSTOMER,
	EMPLOYEE,
	MANAGER
}
