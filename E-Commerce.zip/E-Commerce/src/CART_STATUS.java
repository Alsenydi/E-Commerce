
public enum CART_STATUS { // This enum is used to maintain Cart type
	TEMP,
	PENDING,
	DELIVERED,
	REJECTED
}
