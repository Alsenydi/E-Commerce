1. create database with below configuration 

DB_NAME= "ecommerce-system";
DB_USER= "postgres";
DB_PASSWORD= "123";

or you can paste own configuration in DatabaseManager.java file

3. Run queries written in query.txt file to create tables and insert basic data for test

2. Application Can be run by clicking on jar file or from eclipse by running LoginPage.java as Java application